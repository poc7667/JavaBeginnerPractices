package com.leetcode;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("Hello Java World");

        BigHello bh =  new BigHello();
        bh.bigHello();

        Box box = new Box();
        box.printBox();
    }
}
