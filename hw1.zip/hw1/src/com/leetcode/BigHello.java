package com.leetcode;

/**
 * Created by poc on 6/24/16.
 */
public class BigHello {

    public void bigHello() {
        // write your code here
        System.out.println("H   H    EEEEE   L       L        OOOOO");
        System.out.println("H   H    E       L       L       O     O");
        System.out.println("H   H    E       L       L       O     O");
        System.out.println("HHHHH    EEEEE   L       L       O     O");
        System.out.println("H   H    E       L       L       O     O");
        System.out.println("H   H    E       L       L       O     O");
        System.out.println("H   H    EEEEE   LLLLL   LLLLL    OOOOO");
    }

}
