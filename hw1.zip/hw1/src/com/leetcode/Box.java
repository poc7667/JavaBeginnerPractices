package com.leetcode;

/**
 * Created by poc on 6/24/16.
 */
public class Box {
    public void printBox(){
        System.out.println("------------------");
        System.out.println("|                |");
        System.out.println("|                |");
        System.out.println("|                |");
        System.out.println("|                |");
        System.out.println("|                |");
        System.out.println("|                |");
        System.out.println("------------------");
    }
}
