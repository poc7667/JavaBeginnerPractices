package com.leetcode;

/**
 * Created by poc on 6/27/16.
 */
public class FirstJavaHello {
    public static void main(String[] args) {
        int radius = 2;
        double area;
        final double pi = 3.142;
        area= pi * radius * radius;
        System.out.print("The area is: "+ area);

    }
}
